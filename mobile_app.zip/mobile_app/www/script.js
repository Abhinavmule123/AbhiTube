$(document).ready(function(){
    $("#go-link").on("tap",function(){
        if(localStorage.getItem("app_user") == null){
            $(this).attr("href","#login");
         
        }else{
            $(this).attr("href","#welcome");
            $(this).removeAttr("data-position-to");
            $(this).removeAttr("data-rel");
           
        }
    });
});

$(document).ready(function(){
    let user_name = localStorage.getItem("app_user");
    $("#user-name").html(user_name);

});

$(document).ready(function(){
    $("#homepage").on("swiperight",function(){
        $("#footer").slideDown(100,function(){
            $("#homepage").on("swipeleft",function(){
                $("#footer").slideUp(100);
            });
        });
    });

    $("#welcome").on("swiperight",function(){
        $("#panel-link").click();
    });
});

$(document).ready(function(){
    $("#login-form").on("submit",function(){
        if($("#firstname").val() != "" && $("#lastname").val()){
            let user = $("#firstname").val() + " "+$("#lastname").val();
            localStorage.setItem("app_user",user);
            $.mobile.navigate("#welcome",{transition:"slide"});
        }
    });
});

$(document).ready(function(){
    $("#search-form").submit(function(){
        $("#search-result").html('');
        let keyword = $("#search").val();
        $.ajax({
            type : 'get',
            url:"https://www.googleapis.com/youtube/v3/search",
            data : {
                part : 'snippet , id',
                q : keyword,
                type : 'video',
                key : 'AIzaSyApgqO05wHgClruZoXyvQzUDuDaIh5wKlE',
            },
           beforeSend : function(){
                $("#wait").fadeIn();
           } ,
           success: function(data){
               $("#wait").css("display","none");
            let nextToken = data.nextPageToken;
            let prevToken = data.prevPageToken;
               $(data.items).each(function(){
                let thumb_pic = `<img src="${this.snippet.thumbnails.high.url}" width="80" height="80"`;
                let video_name = `<h4>${this.snippet.title}</h4>`;
                let channel_name = `<p> ${this.snippet.channelTitle}</p>`;
                let video_link = `https://m.youtube.com/watch?v=${this.id.videoId}`;
               
                // $("#search-result li a").click(function(){
                //     window.location = video_link;
                // });
                $("#search-result").append(`<li> <a href="${video_link}"> ${thumb_pic} ${video_name} ${channel_name}</a> </li>`);
                $("#search-result").listview('refresh');
               });

               if(prevToken == undefined || !prevToken){
                   $("#next").css({display : 'block'});
                   $("#next").attr("mytoken",nextToken);
                   $("#next").attr("mykeyword",keyword);
               }else{
                   $("#prev").css({display:'block'});
                   $("#next").css({display:'block'});
                   $("#prev").attr("mytoken",prevToken);
                   $("#prev").attr("mykeyword",keyword);
                   $("#next").attr("mytoken",nextToken);
                   $("#next").attr("mykeyword",keyword);
               }
            },
        })
        return false;
    });
}); 

$(document).ready(function(){
    $("#next").click(function(){
        let mytoken = $("#next").attr("mytoken");
        $("#search-result").html('');
        let keyword = $("#next").attr("mykeyword");
        $.ajax({
            type : 'get',
            url :"https://www.googleapis.com/youtube/v3/search",
            data : {
                part : 'snippet , id',
                q : keyword,
                type : 'video',
                key : 'AIzaSyApgqO05wHgClruZoXyvQzUDuDaIh5wKlE',
                pageToken : mytoken,
            },
            beforeSend : function(){
                $("#wait").fadeIn();
            },
            success: function(data){
                $("#wait").css("display","none");
            let nextToken = data.nextPageToken;
            let prevToken = data.prevPageToken;
               $(data.items).each(function(){
                let thumb_pic = `<img src="${this.snippet.thumbnails.high.url}" width="80" height="80"`;
                let video_name = `<h4>${this.snippet.title}</h4>`;
                let channel_name = `<p> ${this.snippet.channelTitle}</p>`;
                let video_link = `https://m.youtube.com/watch?v=${this.id.videoId}`;
                $("#search-result li a").click(function(){
                    window.location = video_link;
                });
                $("#search-result").append(`<li> <a href="#"> ${thumb_pic} ${video_name} ${channel_name}</a> </li>`);
                $("#search-result").listview('refresh');
               });

               if(prevToken == undefined || !prevToken){
                   $("#next").css({display : 'block'});
                   $("#next").attr("mytoken",nextToken);
                   $("#next").attr("mykeyword",keyword);
               }else{
                $("#prev").css({display:'block'});
                   $("#next").css({display:'block'});
                   $("#prev").attr("mytoken",prevToken);
                   $("#prev").attr("mykeyword",keyword);
                   $("#next").attr("mytoken",nextToken);
                   $("#next").attr("mykeyword",keyword);
               }
            }
        })
        return false;
});
});



$(document).ready(function(){
    $("#prev").click(function(){
        let mytoken = $("#prev").attr("mytoken");
        $("#search-result").html('');
        let keyword = $("#prev").attr("mykeyword");
        $.ajax({
            type : 'get',
            url : "https://www.googleapis.com/youtube/v3/search",
            data : {
                part : 'snippet , id',
                q : keyword,
                type : 'video',
                key : 'AIzaSyApgqO05wHgClruZoXyvQzUDuDaIh5wKlE',
                pageToken : mytoken,
            },
            beforeSend : function(){
                $("#wait").fadeIn();
            },
            success :function(data){
                $("#wait").css("display","none");
            let nextToken = data.nextPageToken;
            let prevToken = data.prevPageToken;
               $(data.items).each(function(){
                let thumb_pic = `<img src="${this.snippet.thumbnails.high.url}" width="80" height="80"`;
                let video_name = `<h4>${this.snippet.title}</h4>`;
                let channel_name = `<p> ${this.snippet.channelTitle}</p>`;
                let video_link = `https://m.youtube.com/watch?v=${this.id.videoId}`;
                $("#search-result li a").click(function(){
                    window.location = video_link;
                });
                $("#search-result").append(`<li> <a href="#"> ${thumb_pic} ${video_name} ${channel_name}</a> </li>`);
                $("#search-result").listview('refresh');
               });

               if(prevToken == undefined || !prevToken){
                   $("#next").css({display : 'block'});
                   $("#next").attr("mytoken",nextToken);
                   $("#next").attr("mykeyword",keyword);
               }else{
                $("#prev").css({display:'block'});
                   $("#next").css({display:'block'});
                   $("#prev").attr("mytoken",prevToken);
                   $("#prev").attr("mykeyword",keyword);
                   $("#next").attr("mytoken",nextToken);
                   $("#next").attr("mykeyword",keyword);
               }
            }
        })
        return false;
    }); 
});

// hompage video key
$(document).ready(function(){
    if(localStorage.getItem("home_key") == null){
        localStorage.setItem("home_key","new hindi songs");
    }
    else{
        setTimeout(function(){
            $("#search-result").html('');
        let keyword = localStorage.getItem("home_key");
        $.ajax({
            type : 'get',
            url:"https://www.googleapis.com/youtube/v3/search",
            data : {
                part : 'snippet , id',
                q : keyword,
                type : 'video',
                key : 'AIzaSyApgqO05wHgClruZoXyvQzUDuDaIh5wKlE',
            },
           beforeSend : function(){
                $("#wait").fadeIn();
           } ,
           success: function(data){
               $("#wait").css("display","none");
            let nextToken = data.nextPageToken;
            let prevToken = data.prevPageToken;
               $(data.items).each(function(){
                let thumb_pic = `<img src="${this.snippet.thumbnails.high.url}" width="80" height="80"`;
                let video_name = `<h4>${this.snippet.title}</h4>`;
                let channel_name = `<p> ${this.snippet.channelTitle}</p>`;
                let video_link = `https://m.youtube.com/watch?v=${this.id.videoId}`;
               
                // $("#search-result li a").click(function(){
                //     window.location = video_link;
                // });
                $("#search-result").append(`<li> <a href="${video_link}"> ${thumb_pic} ${video_name} ${channel_name}</a> </li>`);
                $("#search-result").listview('refresh');
               });

               if(prevToken == undefined || !prevToken){
                   $("#next").css({display : 'block'});
                   $("#next").attr("mytoken",nextToken);
                   $("#next").attr("mykeyword",keyword);
               }else{
                   $("#prev").css({display:'block'});
                   $("#next").css({display:'block'});
                   $("#prev").attr("mytoken",prevToken);
                   $("#prev").attr("mykeyword",keyword);
                   $("#next").attr("mytoken",nextToken);
                   $("#next").attr("mykeyword",keyword);
               }
            },
        });
        return false;
        },2000);
        
    }
});

$(document).ready(function(){
    $("#home-keyword").val(localStorage.getItem("home_key"));
    $("#hompage-form").submit(function(e){
        e.preventDefault();
      let keyword= $("#home-keyword").val();
      localStorage.setItem("home_key",keyword);
      $(".ui-input-btn").css({
        background : "blue",
        color : "white",
      });
      $(".ui-input-btn").buttonMarkup({
        icon:"check",
      });
      setTimeout(function(){
        $("#setting").popup("close");
        $("#search-result").html('');
        let keyword = localStorage.getItem("home_key");
        $.ajax({
            type : 'get',
            url:"https://www.googleapis.com/youtube/v3/search",
            data : {
                part : 'snippet , id',
                q : keyword,
                type : 'video',
                key : 'AIzaSyApgqO05wHgClruZoXyvQzUDuDaIh5wKlE',
            },
           beforeSend : function(){
                $("#wait").fadeIn();
           } ,
           success: function(data){
               $("#wait").css("display","none");
            let nextToken = data.nextPageToken;
            let prevToken = data.prevPageToken;
               $(data.items).each(function(){
                let thumb_pic = `<img src="${this.snippet.thumbnails.high.url}" width="80" height="80"`;
                let video_name = `<h4>${this.snippet.title}</h4>`;
                let channel_name = `<p> ${this.snippet.channelTitle}</p>`;
                let video_link = `https://m.youtube.com/watch?v=${this.id.videoId}`;
               
                // $("#search-result li a").click(function(){
                //     window.location = video_link;
                // });
                $("#search-result").append(`<li> <a href="${video_link}"> ${thumb_pic} ${video_name} ${channel_name}</a> </li>`);
                $("#search-result").listview('refresh');
               });

               if(prevToken == undefined || !prevToken){
                   $("#next").css({display : 'block'});
                   $("#next").attr("mytoken",nextToken);
                   $("#next").attr("mykeyword",keyword);
               }else{
                   $("#prev").css({display:'block'});
                   $("#next").css({display:'block'});
                   $("#prev").attr("mytoken",prevToken);
                   $("#prev").attr("mykeyword",keyword);
                   $("#next").attr("mytoken",nextToken);
                   $("#next").attr("mykeyword",keyword);
               }
            },
        });
      },2000);
    })
});